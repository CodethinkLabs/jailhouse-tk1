_CLC_OVERLOAD _CLC_DECL int atom_xor(global int *p, int val);
_CLC_OVERLOAD _CLC_DECL unsigned int atom_xor(global unsigned int *p, unsigned int val);
