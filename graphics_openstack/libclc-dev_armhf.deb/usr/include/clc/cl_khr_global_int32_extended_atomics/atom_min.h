_CLC_OVERLOAD _CLC_DECL int atom_min(global int *p, int val);
_CLC_OVERLOAD _CLC_DECL unsigned int atom_min(global unsigned int *p, unsigned int val);
