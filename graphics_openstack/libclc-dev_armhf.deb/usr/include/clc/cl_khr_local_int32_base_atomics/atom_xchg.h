_CLC_OVERLOAD _CLC_DECL int atom_xchg(local int *p, int val);
_CLC_OVERLOAD _CLC_DECL unsigned int atom_xchg(local unsigned int *p, unsigned int val);
