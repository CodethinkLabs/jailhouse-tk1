_CLC_OVERLOAD _CLC_DECL int atom_inc(local int *p);
_CLC_OVERLOAD _CLC_DECL unsigned int atom_inc(local unsigned int *p);
