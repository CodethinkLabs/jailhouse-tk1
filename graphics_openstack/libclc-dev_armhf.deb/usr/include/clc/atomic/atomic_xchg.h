#define __CLC_FUNCTION atomic_xchg
#include <clc/atomic/atomic_decl.inc>
__CLC_DECLARE_ATOMIC_ADDRSPACE(float);
#undef __CLC_FUNCTION
#undef __CLC_DECLARE_ATOMIC
#undef __CLC_DECLARE_ATOMIC_ADDRSPACE
