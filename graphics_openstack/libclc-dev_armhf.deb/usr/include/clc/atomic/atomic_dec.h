#define atomic_dec(p) atomic_sub(p, 1)
