_CLC_OVERLOAD _CLC_DECL int atom_inc(global int *p);
_CLC_OVERLOAD _CLC_DECL unsigned int atom_inc(global unsigned int *p);
