#define __CLC_BODY <clc/integer/abs.inc>
#include <clc/integer/gentype.inc>
