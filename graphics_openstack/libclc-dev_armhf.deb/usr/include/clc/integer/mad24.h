#define __CLC_BODY <clc/integer/mad24.inc>
#include <clc/integer/integer-gentype.inc>
#undef __CLC_BODY
