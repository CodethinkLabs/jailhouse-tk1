#define __CLC_BODY <clc/math/fmod.inc>
#include <clc/math/gentype.inc>
