#define __CLC_BODY <clc/math/cos.inc>
#include <clc/math/gentype.inc>
#undef __CLC_BODY
