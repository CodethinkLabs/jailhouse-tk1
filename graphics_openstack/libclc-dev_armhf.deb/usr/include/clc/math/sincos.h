#define __CLC_BODY <clc/math/sincos.inc>
#include <clc/math/gentype.inc>
