#define native_sqrt sqrt
