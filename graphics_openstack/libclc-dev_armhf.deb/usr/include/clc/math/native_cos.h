#define native_cos cos
