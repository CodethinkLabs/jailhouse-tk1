#define native_exp exp
