#define __CLC_BODY <clc/math/acos.inc>
#include <clc/math/gentype.inc>
