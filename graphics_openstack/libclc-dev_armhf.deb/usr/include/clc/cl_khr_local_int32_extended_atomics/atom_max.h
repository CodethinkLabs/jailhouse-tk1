_CLC_OVERLOAD _CLC_DECL int atom_max(local int *p, int val);
_CLC_OVERLOAD _CLC_DECL unsigned int atom_max(local unsigned int *p, unsigned int val);
