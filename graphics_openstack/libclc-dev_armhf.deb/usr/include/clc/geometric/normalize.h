#define __CLC_BODY <clc/geometric/normalize.inc>
#include <clc/geometric/floatn.inc>
